#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 100
#define NAME_LEN 30

char taskNames[SIZE][NAME_LEN];
int front = -1, rear = -1;

// Insert task into queue
void insertTask() {
    if (rear == SIZE - 1) {
        printf("Queue is full - OVERFLOW - No space to enter task.\n");
    } else {
        if (front == -1) {
            front = 0;
        }
        char name[NAME_LEN];
        printf("Enter Task Name: ");
        scanf(" %[^\n]", name);

        rear++;
        strcpy(taskNames[rear], name);

        printf("Task inserted successfully.\n");
    }
}

// Delete task from queue
void deleteTask() {
    if (front == -1 || front == (rear+1)) {
        printf("Queue is empty - UNDERFLOW - No task to delete.\n");
    } else {
        printf("Deleted Task: %s\n", taskNames[front]);
        front++;

        // Reset queue if empty
        if (front > rear) {
            front = 0;
            rear = -1;
        }
    }
}

// Display all tasks in queue
void displayTasks() {
    if (front == -1 || front == (rear+1)) {
        printf("Queue is empty - UNDERFLOW.\n");
    } else {
        printf("\nTasks in Queue:\n");
        printf("----------------------------\n");
        for (int i = front; i <= rear; i++) {
            printf("%d. %s\n", i - front + 1, taskNames[i]);
        }
        printf("----------------------------\n");
    }
}

// Search task from queue (without using 'found' variable)
void searchTask() {
    if (front == -1 || front == (rear+1)) {
        printf("Queue is empty - UNDERFLOW - No task to search.\n");
    } else {
        char searchName[NAME_LEN];
        int i;

        printf("Enter Task Name to Search: ");
        scanf(" %[^\n]", searchName);

        for (i = front; i <= rear; i++) {
            if (strcmp(taskNames[i], searchName) == 0) {
                printf("Task '%s' found at position %d.\n", searchName, i - front + 1);
                break;
            }
        }

        if (i > rear) {
            printf("Task '%s' not found in the queue.\n", searchName);
        }
    }
}

int main() {
    int choice;

    while (1) {
        printf("\n==== Task Scheduler ====\n");
        printf("1. Insert Task\n");
        printf("2. Delete Task\n");
        printf("3. Display Tasks\n");
        printf("4. Search Task\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                insertTask();
                break;
            case 2:
                deleteTask();
                break;
            case 3:
                displayTasks();
                break;
            case 4:
                searchTask();
                break;
            case 5:
                printf("Exiting...\n");
                exit(0);
            default:
                printf("Invalid choice. Try again.\n");
        }} return 0; }
