import sys
sys.stdout.reconfigure(encoding='utf-8')
import re
from collections import Counter

def read_file(file_path):
    """Reads the text file and returns its content as a string."""
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

def clean_text(text):
    """Cleans the text by removing punctuation and converting to lowercase."""
    text = text.lower()  # Convert to lowercase
    text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
    return text

def analyze_text(text):
    """Analyzes the text and returns word frequency statistics."""
    words = text.split()  # Split text into words
    total_words = len(words)  # Total number of words
    word_counts = Counter(words)  # Count frequency of each word
    unique_words = len(word_counts)  # Count of unique words
    most_common = word_counts.most_common(10)  # Top 10 most common words

    return {
        'total_words': total_words,
        'unique_words': unique_words,
        'most_common': most_common,
        'word_counts': word_counts
    }

def print_statistics(stats):
    """Prints the statistics from the analysis."""
    print("\n📊 Text Analysis Results:")
    print(f"Total words: {stats['total_words']}")
    print(f"Unique words: {stats['unique_words']}")
    print("\n🔝 Most common words:")
    for word, count in stats['most_common']:
        print(f"  {word}: {count}")

def main():
    file_path = input("📂 Enter the path to the text file: ")
    try:
        raw_text = read_file(file_path)
        cleaned_text = clean_text(raw_text)
        stats = analyze_text(cleaned_text)
        print_statistics(stats)
    except FileNotFoundError:
        print("❌ File not found. Please check the path and try again.")
    except Exception as e:
        print(f"⚠️ An error occurred: {e}")

if __name__ == "__main__":
    main()
