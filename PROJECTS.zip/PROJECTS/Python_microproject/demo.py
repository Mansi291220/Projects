from analyzer.core import analyze_file, print_stats

def demo():
    filename = 'data/sample.txt'  # Path to your input file
    stats = analyze_file(filename)
    print("Demo: Text Analysis Results:")
    print_stats(stats)

if __name__ == "__main__":
    demo()
