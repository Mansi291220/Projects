from analyzer.core import analyze_file, print_stats

def main():
    filename = 'data/sample.txt'  # Path to your input file
    stats = analyze_file(filename)
    print_stats(stats)

if __name__ == "__main__":
    main()
