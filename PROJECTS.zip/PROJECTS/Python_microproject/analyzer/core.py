import string
from collections import Counter

# Function to load the text file
def load_text(filename):
    with open(filename, 'r', encoding='utf-8') as file:
        return file.read()

# Function to clean the text by removing punctuation and converting to lowercase
def clean_text(text):
    text = text.lower()
    return text.translate(str.maketrans('', '', string.punctuation))

# Function to analyze the cleaned text and get statistics
def analyze_text(text):
    words = text.split()
    total_words = len(words)
    word_counts = Counter(words)
    
    unique_words = len(word_counts)
    most_common = word_counts.most_common(10)

    return {
        'total_words': total_words,
        'unique_words': unique_words,
        'most_common': most_common
    }

# Function to analyze the file, combining all steps
def analyze_file(filename):
    text = load_text(filename)
    cleaned = clean_text(text)
    return analyze_text(cleaned)

# Function to print the statistics in a readable format
def print_stats(stats):
    print("\n📊 Text Statistics:")
    print(f"Total Words: {stats['total_words']}")
    print(f"Unique Words: {stats['unique_words']}")
    print("Most Common Words:")
    for word, count in stats['most_common']:
        print(f"  {word}: {count}")
