import os
import time
import csv

# Task list
task_queue = []

# Helper functions
def print_divider():
    print("=" * 40)

def loading_animation():
    print("Processing", end="")
    for _ in range(3):
        print(".", end="", flush=True)
        time.sleep(0.5)
    print("\n")

def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")

# Core features
def insert_task():
    name = input("Enter Task Name: ").strip()
    priority = input("Enter Priority (1=High, 2=Medium, 3=Low): ").strip()
    due_date = input("Enter Due Date (YYYY-MM-DD): ").strip()

    task = {
        "name": name,
        "priority": int(priority),
        "due_date": due_date
    }

    task_queue.append(task)
    print("Task added successfully.")

def delete_task():
    if not task_queue:
        print("No tasks to delete.")
        return

    print(f"Delete Task: {task_queue[0]['name']} (y/n)? ", end="")
    if input().strip().lower() == 'y':
        deleted = task_queue.pop(0)
        print(f"Deleted: {deleted['name']}")
    else:
        print("Cancelled.")

def display_tasks():
    if not task_queue:
        print("No tasks in the queue.")
        return

    print_divider()
    for idx, task in enumerate(task_queue, 1):
        print(f"{idx}. {task['name']} | Priority: {task['priority']} | Due: {task['due_date']}")
    print_divider()

def search_task():
    name = input("Enter Task Name to Search: ").strip()
    for idx, task in enumerate(task_queue, 1):
        if task['name'].lower() == name.lower():
            print(f"Task found at position {idx}: {task}")
            return
    print("Task not found.")

def sort_tasks():
    task_queue.sort(key=lambda x: x['name'].lower())
    print("Tasks sorted alphabetically.")

def save_tasks():
    with open("tasks.csv", mode="w", newline='') as file:
        writer = csv.DictWriter(file, fieldnames=["name", "priority", "due_date"])
        writer.writeheader()
        writer.writerows(task_queue)
    print("Tasks saved to tasks.csv")

def load_tasks():
    try:
        with open("tasks.csv", mode="r") as file:
            reader = csv.DictReader(file)
            global task_queue
            task_queue = list(reader)
            for task in task_queue:
                task["priority"] = int(task["priority"])  # convert priority back to int
        print("Tasks loaded from tasks.csv")
    except FileNotFoundError:
        print("No saved tasks found.")

# Menu
def main():
    load_tasks()
    loading_animation()

    while True:
        print_divider()
        print("📋 Task Scheduler Menu")
        print_divider()
        print("1. Insert Task")
        print("2. Delete Task")
        print("3. Display Tasks")
        print("4. Search Task")
        print("5. Sort Tasks (A-Z)")
        print("6. Save Tasks")
        print("7. Clear Screen")
        print("8. Exit")
        print_divider()
        choice = input("Enter your choice: ").strip()

        clear_screen()
        if choice == '1':
            insert_task()
        elif choice == '2':
            delete_task()
        elif choice == '3':
            display_tasks()
        elif choice == '4':
            search_task()
        elif choice == '5':
            sort_tasks()
        elif choice == '6':
            save_tasks()
        elif choice == '7':
            clear_screen()
        elif choice == '8':
            save_tasks()
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
